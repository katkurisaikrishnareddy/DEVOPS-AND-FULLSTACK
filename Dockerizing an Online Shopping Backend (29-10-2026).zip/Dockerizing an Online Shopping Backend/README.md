# Dockerized Online Shopping Backend

**Assignment:** 11.2.2 – Dockerizing an Online Shopping Backend  
**Course:** DevOps and Fullstack (23CS102PE405), B.Tech

## Objective

Package a Node.js and Express product API for consistent local and container execution. The project includes a responsive browser console, automated API collection, Docker configuration, and a submission report.

## Technology stack

- Node.js 20 or newer, Express, CORS, and nodemon
- Docker Engine with Docker Compose (optional)
- Postman Collection v2.1
- Plain HTML, CSS, and browser JavaScript

## Features

- In-memory product CRUD API with input validation, search, and category filters
- `/health` endpoint suitable for container health checks
- Request logs with method, URL, status, and elapsed time
- Responsive API console at `/` for listing, filtering, adding, editing, and deleting products
- Graceful SIGINT/SIGTERM shutdown
- Production-only Docker dependencies, Alpine base image, non-root runtime user, and configurable port

## Project structure

```text
shopping-backend/
├── server.js
├── package.json
├── package-lock.json
├── .dockerignore
├── Dockerfile
├── .gitignore
├── .env.example
├── docker-compose.yml
├── README.md
├── public/
│   └── index.html
├── postman/
│   └── shopping-backend.postman_collection.json
└── docs/
    ├── DOCKER_REPORT.md
    └── screenshots/
        └── .gitkeep
```

## API reference

All responses use JSON. Product records have `id`, `name`, `price`, and `category`.

| Method | Route | Description | Success | Error |
|---|---|---|---|---|
| GET | `/api/products` | List; optional case-insensitive `search` and `category` query filters | 200 | — |
| GET | `/api/products/:id` | Read one product | 200 | 404 |
| POST | `/api/products` | Create product; id is max existing id + 1 | 201 | 400 |
| PUT | `/api/products/:id` | Partially update one or more product fields | 200 | 400, 404 |
| DELETE | `/api/products/:id` | Delete and return product | 200 | 404 |
| GET | `/health` | Health and runtime information | 200 | — |

Example list response:

```json
[
  { "id": 1, "name": "Laptop", "price": 60000, "category": "Electronics" },
  { "id": 2, "name": "Headphones", "price": 2000, "category": "Electronics" }
]
```

Example create request:

```json
{ "name": "Wireless Mouse", "price": 1499, "category": "Accessories" }
```

Example create response (on a fresh server):

```json
{ "id": 3, "name": "Wireless Mouse", "price": 1499, "category": "Accessories" }
```

Example update request/response:

```json
{ "price": 62500 }
```

```json
{ "id": 1, "name": "Laptop", "price": 62500, "category": "Electronics" }
```

Example not-found and validation errors:

```json
{ "message": "Product not found" }
```

```json
{ "message": "price must be a positive number" }
```

Example health response (uptime and host values vary):

```json
{
  "status": "ok",
  "version": "1.0.0",
  "uptime": 12.34,
  "timestamp": "2026-10-29T10:11:12.000Z",
  "port": 5000,
  "hostname": "localhost",
  "runningInDocker": false
}
```

## Run locally

Install Node.js 20 or newer, then from this folder:

```powershell
npm install
npm run dev
```

Open [http://localhost:5000](http://localhost:5000). `nodemon` restarts the server when source files change. For production-style local execution, use `npm start`.

Set a different port in PowerShell with `$env:PORT=6000; npm run dev`, or in a POSIX shell with `PORT=6000 npm run dev`. `.env.example` documents the default; dotenv is not used.

## Docker commands

Install and start [Docker Desktop](https://www.docker.com/products/docker-desktop/) on Windows/macOS (enable its WSL 2 engine on Windows) or Docker Engine on Linux. Confirm the daemon is active with `docker info`, then run:

```powershell
docker info
docker build -t shopping-backend:v1 .
docker images
docker run -d -p 5000:5000 --name shopping-api shopping-backend:v1
docker ps
docker inspect --format='{{.State.Health.Status}}' shopping-api
docker logs shopping-api
docker logs -f shopping-api
docker exec shopping-api whoami
docker exec shopping-api id
docker history shopping-backend:v1
docker stop shopping-api
docker rm shopping-api
docker tag shopping-backend:v1 shopping-backend:latest
docker rmi shopping-backend:v1
```

`docker logs -f` follows new output until interrupted with Ctrl+C. To use port 6000 inside and outside the container:

```powershell
docker run -d -p 6000:6000 -e PORT=6000 --name shopping-api shopping-backend:v1
docker inspect --format='{{.State.Health.Status}}' shopping-api
```

To build a new version after changing the application:

```powershell
docker build -t shopping-backend:v2 .
docker images
```

Publishing requires a Docker Hub account. The supplied username `Sai` is written as the lowercase Docker image namespace `sai`. Run `docker login` interactively in your own terminal; never share your password or token in chat.

1. `docker tag shopping-backend:v1 sai/shopping-backend:v1`
2. `docker push sai/shopping-backend:v1`
3. On another system, run `docker pull sai/shopping-backend:v1`
4. Start it with `docker run -p 5000:5000 sai/shopping-backend:v1`

`docker rmi <image>` removes an image when no container depends on it. Do not run `docker system prune` unless you have checked what will be removed and explicitly intend to remove unused Docker data. It can remove unrelated stopped containers, networks, images, and build cache.

An optional Compose workflow is `docker compose up --build -d`, `docker compose ps`, `docker compose logs -f`, and `docker compose down`. Set `$env:PORT=6000` in PowerShell before starting Compose to use port 6000.

## Environment variables

| Variable | Default | Purpose |
|---|---|---|
| `PORT` | `5000` | HTTP port used by the server and Docker health check |
| `RUNNING_IN_DOCKER` | unset locally; `true` in Docker | Health response and console runtime label |
| `NODE_ENV` | Node default locally; `production` in Docker | Runtime mode |

## Dockerfile, line by line

| Instruction | Purpose |
|---|---|
| `FROM node:20-alpine` | Uses the small official Node 20 Alpine image. |
| `ENV NODE_ENV=production PORT=5000 RUNNING_IN_DOCKER=true` | Sets production mode, default port, and container indicator. |
| `WORKDIR /app` | Sets the application working directory. |
| `COPY --chown=node:node package*.json ./` | Copies dependency manifests early for layer caching and node ownership. |
| `RUN npm ci --omit=dev && chown -R node:node /app` | Reproducibly installs production dependencies and sets ownership. |
| `COPY --chown=node:node . .` | Copies the application and public console without root ownership. |
| `EXPOSE 5000` | Documents the container port; it does not publish a host port. |
| `HEALTHCHECK ... wget ...` | Periodically probes `/health` at the configured port. |
| `USER node` | Runs the service as the built-in non-root account. |
| `CMD ["node", "server.js"]` | Starts the backend process. |

`.dockerignore` excludes local dependencies, environment secrets, documentation, Postman files, and Docker development files from the build context, while retaining `public/` and `package-lock.json`.

## Request flow

```text
Source code → Dockerfile → Image → Container → Docker Hub → Any system
```

## Postman

1. Import `postman/shopping-backend.postman_collection.json`.
2. Confirm `baseUrl` is `http://localhost:5000` or change the collection variable.
3. Start the server and run the collection.
4. Each request includes basic status and response assertions. The collection's PUT and DELETE examples use product id `1`; restore/restart the in-memory server between repeated runs if needed.

## Troubleshooting

- **Port already in use:** choose another port, for example `$env:PORT=6000; npm run dev`; for Docker map the same port on each side with `-p 6000:6000 -e PORT=6000`.
- **Docker missing or daemon not running:** install Docker Desktop or Docker Engine, start it, then confirm `docker info` succeeds.
- **Container exits immediately:** inspect `docker logs shopping-api`; verify that the image was built and that the configured port is valid.
- **Unhealthy status:** inspect logs and request `http://localhost:<port>/health`; verify `PORT` matches both the internal listen port and published container port.
- **Dependencies missing:** run `npm install` in the project root.

## Screenshots

Save submission screenshots under `docs/screenshots/`:

- Project tree and source/Docker configuration
- `npm run dev` output and the browser console at `localhost:5000`
- Postman GET, POST, PUT, and DELETE results
- Docker build, images, healthy `docker ps`, logs, and non-root identity
- Port 6000 override, Docker Hub push/repository, and pull/run on another system

## Conclusion

This assignment demonstrates the distinction between containers and virtual machines, images and running containers, Docker layers and dependency caching, runtime environment variables, health checks, and why services should run as non-root. Tags provide versioned references; a registry makes an image available to other systems.

See [docs/DOCKER_REPORT.md](docs/DOCKER_REPORT.md) for the procedure, observed local outputs, requirements checklist, and Docker verification status.
