# Assignment 11.2.2 – Dockerizing an Online Shopping Backend

**Course:** DevOps and Fullstack (23CS102PE405), B.Tech  
**Scenario:** Package a Node.js/Express product backend for consistent development and deployment.

## Aim

Create and verify an in-memory shopping product API, a browser-based API console, an importable Postman collection, and a production-oriented Docker image definition.

## Tools and setup

| Tool | Observed |
|---|---|
| Operating system | Windows / PowerShell |
| Node.js | `v24.18.0` |
| npm | `11.16.0` |
| Docker CLI / daemon | Unavailable: `docker` command is not recognized in this environment |

The project was initialized and dependencies installed with `npm init -y`, `npm install express cors`, and `npm install --save-dev nodemon`. npm reported 0 vulnerabilities on both install runs. Docker build/run/image/health/log/identity and Docker Hub steps could not be executed because Docker is not installed or available on PATH. No Docker output is represented as if it had run.

## Procedure and implementation

1. Created the Node.js project with `server.js` as its entry point, `start` and `dev` scripts, and Node `>=20` engine requirement. `package-lock.json` is committed as a project file.
2. Implemented the five product REST operations (list, read, create, update, delete), case-insensitive filters, validation, JSON errors, route fallback, request logging, versioned health response, static browser console, and graceful signal handling in `server.js`.
3. Added a mobile-responsive console in `public/index.html`. It fetches health and product data, filters, and manages products without navigation, and displays the last request and JSON result.
4. Added the six-request Postman v2.1 collection with the `baseUrl` default and status/body tests.
5. Added Docker build configuration, non-root ownership/user, production dependency install, variable-aware health check, `.dockerignore`, and optional Compose service.
6. Documented local/Docker commands and submission evidence in `README.md` and this report.

## Dockerfile explanation

The Dockerfile starts with `node:20-alpine`, declares production mode, `PORT=5000`, and `RUNNING_IN_DOCKER=true`, then sets `/app` as its working directory. It copies `package*.json` first to reuse the dependency layer, runs `npm ci --omit=dev`, and then copies source with `node:node` ownership. `EXPOSE 5000` documents the application port. The shell-form health check calls `wget` against `127.0.0.1:${PORT}/health`; `USER node` drops root privileges before `CMD ["node", "server.js"]` launches the service.

The `.dockerignore` excludes `node_modules`, npm debug logs, Git metadata, environment files, docs, Postman assets, README, and Docker build/config files. It does not exclude `public/` or `package-lock.json`.

## Verification results and real output

### Environment and dependency installation

Observed command output:

```text
node -v
v24.18.0

npm -v
11.16.0

npm install express cors
added 67 packages, and audited 68 packages in 3s
found 0 vulnerabilities

npm install --save-dev nodemon
added 26 packages, and audited 94 packages in 2s
found 0 vulnerabilities
```

The Docker availability probe returned:

```text
docker : The term 'docker' is not recognized as the name of a cmdlet,
function, script file, or operable program.
```

Therefore the requested Docker build, `docker images/history`, container runs, `docker ps`, `docker inspect`, `docker logs`, `docker exec`, port-6000 test, version tagging, and push/pull were **not run**. Install Docker Desktop for Windows, start its daemon, and verify `docker info` before capturing these outputs.

### Local API test results

Run `npm run dev` and `npm start` were run on port 5000, and `node server.js` was also started directly. Each served the API; the home page returned HTTP 200. The application binds to `0.0.0.0`. On save of the version-field change in `server.js`, nodemon logged `restarting due to changes...`, started the server again, and the post-reload API checks passed.

The final HTTP regression checks used Node's built-in `fetch` against the real `npm run dev` server. Observed results:

```text
GET /api/products -> 200 [Laptop, Headphones]
GET /api/products?search=LAPTOP&category=electronics -> 200 [Laptop]
GET /api/products?category=tronics -> 200 []
GET /api/products/1 -> 200 Laptop
GET /api/products/999 -> 404 {"message":"Product not found"}
POST /api/products (valid) -> 201 {"id":3,"name":"Wireless Mouse","price":1499,"category":"Accessories"}
POST /api/products (invalid) -> 400 {"message":"name must be a non-empty string"}
PUT /api/products/1 -> 200; price updated to 62500
POST /api/products -> 201 id 4
DELETE /api/products/4 -> 200
POST /api/products -> 201 id 5 (deleted id 4 was not reused)
DELETE /api/products/1 -> 200
DELETE /api/products/999 -> 404 {"message":"Product not found"}
POST /api/products (malformed JSON) -> 400 {"message":"Malformed JSON request body"}
GET /api/not-a-route -> 404 {"message":"Route not found"}
GET /health -> 200 {"status":"ok","version":"1.0.0","port":5000,"runningInDocker":false,...}
GET / -> 200 (Shopping Backend – API Console HTML)
PASS: all endpoint, validation, filtering, malformed JSON, static page, and non-reused ID checks
```

Direct checks also returned `GET /health` with `status=ok`, `version=1.0.0`, `port=5000`, `runningInDocker=False`, and `GET /` with HTTP 200 and title `Shopping Backend – API Console`. The terminal showed:

```text
> shopping-backend@1.0.0 dev
> nodemon server.js
[nodemon] starting `node server.js`
Server running on port 5000

> shopping-backend@1.0.0 start
> node server.js
Server running on port 5000
```

In PowerShell, the API can also be probed with `Invoke-RestMethod`; use `Invoke-WebRequest` when you need the response status and HTML content.

The application-level port override was also run locally:

```text
$env:PORT='6000'; node server.js
Server running on port 6000
GET http://localhost:6000/health -> HTTP 200, status=ok, port=6000
```

This confirms the server honors `PORT`; it is not a substitute for the still-pending Docker port mapping and container health-check experiment.

### Docker Hub procedure

Docker Hub username `Sai` was supplied; the image namespace is written lowercase as `sai`. Docker remains unavailable in this workspace. After Docker is installed and authenticated interactively with `docker login`, run:

1. `docker tag shopping-backend:v1 sai/shopping-backend:v1`
2. `docker push sai/shopping-backend:v1`
3. On another system, `docker pull sai/shopping-backend:v1`
4. On another system, `docker run -p 5000:5000 sai/shopping-backend:v1`

Never paste passwords or access tokens into chat. Do not run `docker system prune` without explicitly reviewing and approving the unrelated data it could remove.

## Observations and challenges

- Node/npm were present and dependency installation completed with no reported npm vulnerabilities.
- Docker CLI was missing from PATH, preventing truthful end-to-end Docker validation and screenshot capture.
- The product list is intentionally in-memory, so a server restart resets it to the two assignment seed records.

## Requirements checklist

| Requirement | Implemented? | Where |
|---|---|---|
| Dockerized shopping backend | Docker configuration implemented; image build unverified | `Dockerfile`, Docker build command pending |
| Product REST API (5 endpoints) | Yes | `server.js` (`/api/products` list/read/create/update/delete) |
| Docker image | Not built: Docker unavailable | `docker build -t shopping-backend:v1 .` pending |
| Docker container | Not run: Docker unavailable | `docker run` / `docker ps` pending |
| Environment configuration | Yes | `server.js`, `Dockerfile`, `.env.example`, `docker-compose.yml` |
| Postman API testing | Collection implemented; execution unverified | `postman/shopping-backend.postman_collection.json` |
| Docker Hub image | Not published: Docker unavailable and username not supplied | README/report replacement-ready commands |
| Environment variables | Yes; port-6000 runtime test blocked | `PORT`, `RUNNING_IN_DOCKER`, `NODE_ENV`; Docker commands pending |
| `.dockerignore` | Yes | `.dockerignore` |
| Lightweight Alpine image | Yes in definition; image size unverified | `Dockerfile` (`node:20-alpine`) |
| Image tagging | Commands documented; not run | README Docker command list |
| Container logs | Request logger implemented; Docker logs not run | `server.js`; `docker logs shopping-api` pending |
| Health check | Endpoint and Docker health check implemented; runtime health unverified | `server.js`, `Dockerfile` |
| Non-root execution | `USER node` configured; runtime identity unverified | `Dockerfile` |

## Viva questions and answers

1. **What is the difference between `CMD` and `ENTRYPOINT`?** `ENTRYPOINT` defines the executable; `CMD` supplies default command/arguments that are easier to override.
2. **Why use `npm ci --omit=dev`?** It installs exact lockfile dependencies reproducibly and excludes development-only packages from production.
3. **Why copy `package.json` and the lock file before source?** Dependency layers can be reused when application source changes but dependencies do not.
4. **What is the difference between `EXPOSE` and `-p`?** `EXPOSE` documents a container port; `-p` publishes/maps a container port to a host port.
5. **What does `HEALTHCHECK` do?** Docker periodically runs a probe and records whether the container is healthy; it does not itself repair a failed service.
6. **Why run as non-root?** It reduces the privileges available to a compromised application process.
7. **What is the difference between an image and a container?** An image is the packaged template; a container is a running (or stopped) instance of that image.
8. **Why use tags and a registry?** Tags identify image versions; a registry stores and distributes those images to other hosts.

## Conclusion

The application and Docker configuration are prepared, and local API/runtime validation remains to be captured. Docker installation and daemon access are the blocking prerequisites for confirming container health, port overrides, non-root runtime, image size, and publishing.
