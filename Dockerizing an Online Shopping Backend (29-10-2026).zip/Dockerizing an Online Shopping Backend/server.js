'use strict';

const express = require('express');
const cors = require('cors');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 5000;

let products = [
  { id: 1, name: 'Laptop', price: 60000, category: 'Electronics' },
  { id: 2, name: 'Headphones', price: 2000, category: 'Electronics' }
];
let nextProductId = Math.max(...products.map((product) => product.id)) + 1;

app.use((req, res, next) => {
  const startedAt = process.hrtime.bigint();
  res.on('finish', () => {
    const durationMs = Number(process.hrtime.bigint() - startedAt) / 1e6;
    console.log(JSON.stringify({
      method: req.method,
      url: req.originalUrl,
      status: res.statusCode,
      durationMs: Number(durationMs.toFixed(2))
    }));
  });
  next();
});

app.use(cors());
app.use(express.json());

function isRecord(value) {
  return value !== null && typeof value === 'object' && !Array.isArray(value);
}

function parseProductId(value) {
  if (!/^[1-9]\d*$/.test(value)) {
    return null;
  }

  const id = Number(value);
  return Number.isSafeInteger(id) ? id : null;
}

function validateProductFields(fields, current = {}) {
  const product = { ...current };

  if (Object.prototype.hasOwnProperty.call(fields, 'name')) {
    if (typeof fields.name !== 'string' || fields.name.trim() === '') {
      return { error: 'name must be a non-empty string' };
    }
    product.name = fields.name.trim();
  } else if (!current.name) {
    return { error: 'name is required' };
  }

  if (Object.prototype.hasOwnProperty.call(fields, 'price')) {
    if (typeof fields.price !== 'number' || !Number.isFinite(fields.price) || fields.price <= 0) {
      return { error: 'price must be a positive number' };
    }
    product.price = fields.price;
  } else if (current.price === undefined) {
    return { error: 'price is required' };
  }

  if (Object.prototype.hasOwnProperty.call(fields, 'category')) {
    if (typeof fields.category !== 'string' || fields.category.trim() === '') {
      return { error: 'category must be a non-empty string' };
    }
    product.category = fields.category.trim();
  } else if (!current.category) {
    return { error: 'category is required' };
  }

  return { product };
}

app.get('/api/products', (req, res) => {
  const search = typeof req.query.search === 'string' ? req.query.search.trim().toLowerCase() : '';
  const category = typeof req.query.category === 'string' ? req.query.category.trim().toLowerCase() : '';
  const result = products.filter((product) => {
    return product.name.toLowerCase().includes(search)
      && (!category || product.category.toLowerCase() === category);
  });
  res.status(200).json(result);
});

app.get('/api/products/:id', (req, res) => {
  const id = parseProductId(req.params.id);
  const product = id === null ? undefined : products.find((item) => item.id === id);
  if (!product) {
    return res.status(404).json({ message: 'Product not found' });
  }
  return res.status(200).json(product);
});

app.post('/api/products', (req, res) => {
  if (!isRecord(req.body)) {
    return res.status(400).json({ message: 'Request body must be a JSON object' });
  }

  const validated = validateProductFields(req.body);
  if (validated.error) {
    return res.status(400).json({ message: validated.error });
  }

  const id = nextProductId;
  nextProductId += 1;
  const product = { id, ...validated.product };
  products.push(product);
  return res.status(201).json(product);
});

app.put('/api/products/:id', (req, res) => {
  const id = parseProductId(req.params.id);
  const index = id === null ? -1 : products.findIndex((item) => item.id === id);
  if (index === -1) {
    return res.status(404).json({ message: 'Product not found' });
  }
  if (!isRecord(req.body)) {
    return res.status(400).json({ message: 'Request body must be a JSON object' });
  }

  const fields = Object.fromEntries(
    Object.entries(req.body).filter(([key]) => ['name', 'price', 'category'].includes(key))
  );
  if (Object.keys(fields).length === 0) {
    return res.status(400).json({ message: 'At least one product field is required' });
  }

  const validated = validateProductFields(fields, products[index]);
  if (validated.error) {
    return res.status(400).json({ message: validated.error });
  }

  products[index] = { id, ...validated.product };
  return res.status(200).json(products[index]);
});

app.delete('/api/products/:id', (req, res) => {
  const id = parseProductId(req.params.id);
  const index = id === null ? -1 : products.findIndex((item) => item.id === id);
  if (index === -1) {
    return res.status(404).json({ message: 'Product not found' });
  }

  const [product] = products.splice(index, 1);
  return res.status(200).json({ message: 'Product deleted', product });
});

app.get('/health', (req, res) => {
  res.status(200).json({
    status: 'ok',
    version: '1.0.0',
    uptime: process.uptime(),
    timestamp: new Date().toISOString(),
    port: Number(PORT),
    hostname: req.hostname,
    runningInDocker: process.env.RUNNING_IN_DOCKER === 'true'
  });
});

app.use(express.static(path.join(__dirname, 'public')));

app.use((req, res) => {
  res.status(404).json({ message: 'Route not found' });
});

app.use((error, req, res, next) => {
  if (res.headersSent) {
    return next(error);
  }
  if (error.type === 'entity.parse.failed') {
    return res.status(400).json({ message: 'Malformed JSON request body' });
  }
  console.error('Request error:', error);
  return res.status(error.status >= 400 && error.status < 600 ? error.status : 500)
    .json({ message: 'Internal server error' });
});

let server;

function shutdown(signal) {
  console.log(`${signal} received; shutting down`);
  if (!server) {
    process.exit(0);
    return;
  }
  server.close((error) => {
    if (error) {
      console.error('Error during shutdown:', error);
      process.exitCode = 1;
      return;
    }
    console.log('HTTP server closed');
  });
}

if (require.main === module) {
  server = app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running on port ${PORT}`);
  });

  process.once('SIGTERM', () => shutdown('SIGTERM'));
  process.once('SIGINT', () => shutdown('SIGINT'));
}

module.exports = app;
